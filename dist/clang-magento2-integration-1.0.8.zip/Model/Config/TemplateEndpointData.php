<?php

namespace Clang\Clang\Model\Config;

use Magento\Framework\Config\Data as DataConfig;

class TemplateEndpointData extends DataConfig
{
}
